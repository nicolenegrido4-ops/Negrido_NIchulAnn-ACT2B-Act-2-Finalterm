<?php require_once __DIR__ . '/auth.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title ?? 'PHP CRUD System') ?></title>
<style>
body{font-family:Arial,sans-serif;background:#f4f6f9;margin:0;color:#222}
nav{background:#172b4d;padding:14px 5%;display:flex;gap:18px;align-items:center;flex-wrap:wrap}
nav a{color:white;text-decoration:none}
nav .brand{font-weight:bold;margin-right:auto}
main{max-width:1050px;margin:28px auto;padding:0 16px}
.card{background:white;padding:22px;border-radius:8px;box-shadow:0 2px 9px #0001;margin-bottom:18px}
input,textarea,select{width:100%;padding:10px;margin:6px 0 14px;box-sizing:border-box;border:1px solid #ccd2da;border-radius:4px}
button,.btn{display:inline-block;background:#1769aa;color:white;padding:9px 13px;border:0;border-radius:4px;text-decoration:none;cursor:pointer}
.danger{background:#b42318}.muted{color:#667085}.error{color:#b42318}
table{width:100%;border-collapse:collapse;background:white}
th,td{padding:11px;border-bottom:1px solid #e5e7eb;text-align:left}
.actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.inline{display:inline}
</style>
</head>
<body>
<nav>
<a class="brand" href="dashboard.php">PHP CRUD System</a>
<?php if (!empty($_SESSION['user'])): ?>
<a href="dashboard.php">Dashboard</a>
<a href="products.php">Products</a>
<?php if (is_admin()): ?><a href="users.php">User Management</a><?php endif; ?>
<span style="color:white">Hi, <?= e(current_user()['name'] ?? '') ?> (<?= e(current_user()['role'] ?? '') ?>)</span>
<a href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><?php endif; ?>
</nav>
<main>
