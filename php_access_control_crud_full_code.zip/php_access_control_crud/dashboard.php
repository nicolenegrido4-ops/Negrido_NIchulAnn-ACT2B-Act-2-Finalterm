<?php
require_once __DIR__ . '/includes/auth.php';
require_login();

$productCount = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$userCount = is_admin() ? (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() : null;
$page_title = 'Dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
<h1>Dashboard</h1>
<p>Welcome, <?= e(current_user()['name']) ?>.</p>
<p>Your role is <strong><?= e(current_user()['role']) ?></strong>.</p>
</div>
<div class="card"><h3>Products</h3><p><?= $productCount ?> product record(s)</p><a class="btn" href="products.php">Manage products</a></div>
<?php if (is_admin()): ?>
<div class="card"><h3>Users</h3><p><?= $userCount ?> user account(s)</p><a class="btn" href="users.php">Manage users</a></div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
