<?php
require_once __DIR__ . '/includes/auth.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $quantity = filter_var($_POST['quantity'] ?? null, FILTER_VALIDATE_INT);
        $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);

        if ($name === '' || $quantity === false || $quantity < 0 || $price === false || $price < 0) {
            exit('Invalid product details. <a href="products.php">Go back</a>');
        }

        if ($action === 'create') {
            $stmt = $pdo->prepare('INSERT INTO products (name, description, quantity, price) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $description, $quantity, $price]);
        } else {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) exit('Invalid product ID.');
            $stmt = $pdo->prepare('UPDATE products SET name=?, description=?, quantity=?, price=? WHERE id=?');
            $stmt->execute([$name, $description, $quantity, $price, $id]);
        }
        redirect('products.php');
    }

    if ($action === 'delete') {
        // Staff may not delete. Admins can.
        if (!is_admin()) {
            http_response_code(403);
            exit('403 Forbidden: Only administrators can delete products.');
        }
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) exit('Invalid product ID.');
        $stmt = $pdo->prepare('DELETE FROM products WHERE id = ?');
        $stmt->execute([$id]);
        redirect('products.php');
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = filter_var($_GET['edit'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id=?');
        $stmt->execute([$id]);
        $edit = $stmt->fetch() ?: null;
    }
}
$products = $pdo->query('SELECT * FROM products ORDER BY id DESC')->fetchAll();
$page_title = 'Products';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
<h2><?= $edit ? 'Edit product' : 'Add product' ?></h2>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
<label>Product name</label><input name="name" maxlength="150" required value="<?= e($edit['name'] ?? '') ?>">
<label>Description</label><textarea name="description"><?= e($edit['description'] ?? '') ?></textarea>
<label>Quantity</label><input type="number" name="quantity" min="0" required value="<?= e((string)($edit['quantity'] ?? 0)) ?>">
<label>Price</label><input type="number" name="price" min="0" step="0.01" required value="<?= e((string)($edit['price'] ?? '0.00')) ?>">
<button type="submit"><?= $edit ? 'Update' : 'Create' ?></button>
<?php if ($edit): ?> <a class="btn" href="products.php">Cancel</a><?php endif; ?>
</form>
</div>
<div class="card">
<h2>Product list</h2>
<table><thead><tr><th>ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($products as $p): ?>
<tr>
<td><?= (int)$p['id'] ?></td><td><?= e($p['name']) ?></td><td><?= (int)$p['quantity'] ?></td><td><?= number_format((float)$p['price'], 2) ?></td>
<td class="actions">
<a class="btn" href="products.php?edit=<?= (int)$p['id'] ?>">Edit</a>
<?php if (is_admin()): ?>
<form class="inline" method="post" onsubmit="return confirm('Delete this product?')">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
<button class="danger" type="submit">Delete</button>
</form>
<?php endif; ?>
</td></tr>
<?php endforeach; ?>
<?php if (!$products): ?><tr><td colspan="5">No products found.</td></tr><?php endif; ?>
</tbody></table>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
