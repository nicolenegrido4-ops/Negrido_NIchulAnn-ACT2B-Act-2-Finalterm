PHP + MySQL Access Control, User Management, and CRUD Sample
=============================================================

WHAT IS INCLUDED
- Login and logout using PHP sessions.
- Password hashing with password_hash() and password_verify().
- Two roles: admin and staff.
- Server-side access checks (users.php is admin-only).
- User management CRUD: create, list, update, delete accounts.
- Product CRUD: create, list, update, delete products.
- Staff can create/read/update products; only admin can delete products.
- PDO prepared statements, output escaping, CSRF tokens, session ID regeneration.

REQUIREMENTS
- PHP 8.1+ with PDO MySQL enabled.
- MySQL or MariaDB.
- XAMPP/WAMP/LAMP or a PHP-capable web server.

INSTALLATION (XAMPP)
1. Extract this folder into htdocs, for example:
   C:\xampp\htdocs\php_access_control_crud
2. Start Apache and MySQL in the XAMPP Control Panel.
3. Open phpMyAdmin and import database.sql.
   This creates the school_crud database, users table, and products table.
4. Open config.php and set the MySQL username/password for your machine.
   Default XAMPP settings are often root with a blank password.
5. Visit:
   http://localhost/php_access_control_crud/create_admin.php
   It creates:
   Email: admin@example.com
   Temporary password: ChangeMe123!
6. IMPORTANT: Delete create_admin.php immediately after the admin is created.
7. Visit:
   http://localhost/php_access_control_crud/
   Log in with the temporary admin credentials.
8. Create staff accounts from User Management. Change the temporary admin
   password by editing that admin account and entering a new password.

ROLE / PERMISSION MATRIX
- Dashboard: logged-in admin and staff.
- Product list/create/edit: logged-in admin and staff.
- Product delete: admin only.
- User management CRUD: admin only.
- Login/logout: public/authenticated as appropriate.

IMPORTANT FOR AN EXISTING PROJECT
This is a complete reference implementation, not a patch against your existing
source code. Back up your project first. Merge the database tables, shared
authentication functions, and permission checks into your existing files.
If your project already has a users table, compare its columns before importing
database.sql; do not overwrite existing data.

SECURITY / DEPLOYMENT NOTES
- Use HTTPS in production.
- Set secure session cookie options when deploying behind HTTPS.
- Keep config.php and create_admin.php out of public access where possible;
  at minimum, delete create_admin.php after setup.
- Use a strong unique admin password.
- Add validation and authorization rules that match your actual project.
- Never rely only on hiding buttons or menu links; enforce permissions on the
  server for every protected page and action.
