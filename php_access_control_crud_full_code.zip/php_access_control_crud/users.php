<?php
require_once __DIR__ . '/includes/auth.php';
require_admin(); // Enforce access on the server, not just by hiding the menu.

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $role = $_POST['role'] ?? 'staff';
        $password = $_POST['password'] ?? '';

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($role, ['admin','staff'], true)) {
            exit('Please enter valid user details. <a href="users.php">Go back</a>');
        }

        if ($action === 'create') {
            if (strlen($password) < 8) exit('Password must be at least 8 characters.');
            $stmt = $pdo->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)');
            try {
                $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') exit('That email is already registered.');
                throw $e;
            }
        } else {
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) exit('Invalid user ID.');
            if ($id === (int)current_user()['id'] && $role !== 'admin') {
                exit('You cannot remove your own administrator role.');
            }
            if ($password !== '') {
                if (strlen($password) < 8) exit('New password must be at least 8 characters.');
                $stmt = $pdo->prepare('UPDATE users SET name=?, email=?, role=?, password=? WHERE id=?');
                $stmt->execute([$name, $email, $role, password_hash($password, PASSWORD_DEFAULT), $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE users SET name=?, email=?, role=? WHERE id=?');
                $stmt->execute([$name, $email, $role, $id]);
            }
            // Refresh this session if the administrator edited their own profile.
            if ($id === (int)current_user()['id']) {
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                $_SESSION['user']['role'] = $role;
            }
        }
        redirect('users.php');
    }

    if ($action === 'delete') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) exit('Invalid user ID.');
        if ($id === (int)current_user()['id']) exit('You cannot delete your own account while logged in.');
        $stmt = $pdo->prepare('DELETE FROM users WHERE id=?');
        $stmt->execute([$id]);
        redirect('users.php');
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = filter_var($_GET['edit'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare('SELECT id,name,email,role FROM users WHERE id=?');
        $stmt->execute([$id]);
        $edit = $stmt->fetch() ?: null;
    }
}
$users = $pdo->query('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC')->fetchAll();
$page_title = 'User Management';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
<h2><?= $edit ? 'Edit user' : 'Create user' ?></h2>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
<label>Full name</label><input name="name" maxlength="100" required value="<?= e($edit['name'] ?? '') ?>">
<label>Email</label><input type="email" name="email" maxlength="190" required value="<?= e($edit['email'] ?? '') ?>">
<label>Role</label><select name="role">
<option value="staff" <?= (($edit['role'] ?? '') === 'staff') ? 'selected' : '' ?>>Staff</option>
<option value="admin" <?= (($edit['role'] ?? '') === 'admin') ? 'selected' : '' ?>>Admin</option>
</select>
<label><?= $edit ? 'New password (leave blank to keep current password)' : 'Password (minimum 8 characters)' ?></label>
<input type="password" name="password" minlength="8" <?= $edit ? '' : 'required' ?> autocomplete="new-password">
<button type="submit"><?= $edit ? 'Update user' : 'Create user' ?></button>
<?php if ($edit): ?> <a class="btn" href="users.php">Cancel</a><?php endif; ?>
</form>
</div>
<div class="card">
<h2>Registered users</h2>
<table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($users as $u): ?>
<tr><td><?= (int)$u['id'] ?></td><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td><td><?= e($u['role']) ?></td><td><?= e($u['created_at']) ?></td>
<td class="actions"><a class="btn" href="users.php?edit=<?= (int)$u['id'] ?>">Edit</a>
<?php if ((int)$u['id'] !== (int)current_user()['id']): ?>
<form class="inline" method="post" onsubmit="return confirm('Delete this user account?')">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
<button class="danger" type="submit">Delete</button></form>
<?php else: ?><span class="muted">Current account</span><?php endif; ?>
</td></tr>
<?php endforeach; ?>
<?php if (!$users): ?><tr><td colspan="6">No users found.</td></tr><?php endif; ?>
</tbody></table>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
