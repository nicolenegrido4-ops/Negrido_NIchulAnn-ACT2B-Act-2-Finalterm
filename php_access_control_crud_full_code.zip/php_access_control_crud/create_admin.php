<?php
// Run once in your browser, then DELETE this file from the project.
require_once __DIR__ . '/config.php';

$name = 'Administrator';
$email = 'admin@example.com';
$plainPassword = 'ChangeMe123!';

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    exit('Admin already exists. Delete create_admin.php now.');
}

$hash = password_hash($plainPassword, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'admin')");
$stmt->execute([$name, $email, $hash]);

echo 'Admin created. Email: ' . htmlspecialchars($email) .
     '. Temporary password: ' . htmlspecialchars($plainPassword) .
     '. Log in and change the password. DELETE create_admin.php now.';
