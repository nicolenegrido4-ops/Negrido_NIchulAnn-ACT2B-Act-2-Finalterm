<?php
require_once __DIR__ . '/includes/auth.php';

if (!empty($_SESSION['user'])) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT id, name, email, password, role FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        unset($user['password']);
        $_SESSION['user'] = $user;
        redirect('dashboard.php');
    }
    $error = 'Incorrect email or password.';
}
$page_title = 'Login';
require __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:440px;margin:40px auto">
<h2>Login</h2>
<?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Email</label><input type="email" name="email" required autocomplete="username">
<label>Password</label><input type="password" name="password" required autocomplete="current-password">
<button type="submit">Sign in</button>
</form>
<p class="muted">First setup: create an administrator using create_admin.php, then delete that setup file.</p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
